/*
 * Lauren Spruce
 * ID: 18011848
 */

public class SequentialSearchNFA{

  /*
   * The transition function represented as an array.
   * The entry at delta[s,c-'0'] is an array of 0 or
   * more ints, one for each possible move from 
   * the state s on the character c.
   */
  private static int[][][] delta = //3-dimensonal array
  { {{0,1},{0}}, {{2},{2,3}},{{1},{3}},{{},{}} };
  // in this 3 dimensional we encode the states as a result of the transitions. 
  // Start state input a = [0][0][0] / [0][0][1] which represent the state we can go to {0,1} because if we input a we can go state 0 or 1.
  // Start state input b =  [0][1][0] from start input b stays in 0.

  /* 
   * Constants q0 through q4 represent states
   */
  private static int q0 = 0; // initial state
  private static final int q1 = 1; //The second state , state n1 
  private static final int q2 = 2; // The third state, state n2
  private static final int q3 = 3; //the last state , state n3
  private static final int q4 = 4; // the sink state is for when we are in the state 3 input a and b don't go anywhere so the sink is for this cases 

  /**
   * Test whether there is some path for the NFA to
   * reach an accepting state from the given state,
   * reading the given string at the given character
   * position.
   * @param s the current state
   * @param in the input string
   * @param pos index of the next char in the string
   * @return true if the NFA accepts on some path
   */
  private static boolean acceptsNext
      (int state, String in, int pos) {
    if (pos==in.length()) { // if no more to read
      return (state==q1 || state==q3);   // in our NFA the final states are in q1 and q3
    }

    char c = in.charAt(pos++); // get char and advance the position
    int[] nextStates;
    try {
      nextStates = delta[state][c-'a']; // transition to the next position
      //c-a == difference of ASCII code c-a = 0 c-b = 1 
    }
    catch (ArrayIndexOutOfBoundsException ex) {
      return false; // no transition, reject the entire string
    }

    // At this point after the transition, nextStates is an array 
    // of 0 ormore next states.  Try each move recursively;
    // if it leads to an accepting state return true.

    for (int i=0; i < nextStates.length; i++) {
      if (acceptsNext(nextStates[i], in, pos)) return true;
    }

    return false; // all moves fail, reject the entire string
  }


  /**
   * Test whether the NFA accepts the string.
   * @param in the String to test
   * @return true if the NFA accepts on some path
   */
  public static boolean accepts(String in) {
    return acceptsNext(q0, in, 0); // start of the recursion in state q0 at char 0
  }
  
}
