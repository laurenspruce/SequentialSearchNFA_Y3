/*
 * Lauren Spruce
 * ID: 18011848
 */

import java.io.*;

/**
 * My Java application to show my SequentialSearchFilter
 * This application filters the input stream, whatever inputs are entered. 
 * Any line of strings which are accepted or rejected will get outputted to the standard output.
 * Therefore the user can see the outputs for any word they input.
 **/

public class SequentialSearchFilter {
  public static void main(String[] args) 
        throws IOException {

    System.out.println("Hello, this is a program to check strings of words for my NFA using sequential searching!");
    System.out.println("Please enter your following words to be checked if they are accepted or rejected:");
    
    BufferedReader in =  // standard input
      new BufferedReader(new InputStreamReader(System.in)); //Allows the text to be read from an input streamreader, which also allows files to be read.
    //Allows buffering of characters so they can be easily read. Reads and echo's lines until the end of the file

    String s = in.readLine(); //Starts to read the strings as they are inputted 
    
    while (s!=null) {
      if (SequentialSearchNFA.accepts(s)) System.out.println("Accepted: " + s + "\n");// if bits accepted, displays a 'accepted' message along with the string accepted otherwise skipped.
      else{
          System.out.println("Rejected: " + s + "\n"); //If the string isn't accepted, will display reject message along with the string.
      }
      
      s = in.readLine(); //Continues to read the strings as they are inputted
    }
  }
}

